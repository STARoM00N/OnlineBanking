package com.bankapp.controllers;

import com.bankapp.repositories.UserRepository;
import com.bankapp.services.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.bankapp.models.Transaction;

import java.math.BigDecimal;
import java.security.Principal;

@Controller
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/deposit")
    public String showDepositPage() {
        return "deposit"; // ชื่อไฟล์ HTML สำหรับหน้าการเติมเงิน
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam BigDecimal amount, Model model, Principal principal) {
        Long userId = getUserIdFromPrincipal(principal);
        transactionService.deposit(userId, amount);
        model.addAttribute("successMessage", "Deposit successful!");
        return "redirect:/dashboard";
    }

    @GetMapping("/balance")
    public String getBalance(Model model, Principal principal) {
        Long userId = getUserIdFromPrincipal(principal);
        BigDecimal balance = transactionService.getUserBalance(userId);
        model.addAttribute("balance", balance);
        return "balance"; // HTML สำหรับแสดงยอดเงิน
    }

    @GetMapping("/transactions/transaction-history")
    public String getTransactionHistory(Model model, Principal principal) {
        Long userId = userRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new IllegalArgumentException("User not found"))
                .getId();
        List<Transaction> transactions = transactionService.getTransactionHistory(userId);

        // Debugging Log
        System.out.println("Transaction History: " + transactions);
        model.addAttribute("transactions", transactions);
        return "transaction-history"; // HTML template ชื่อ transaction-history.html
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam BigDecimal amount, Model model, Principal principal) {
        try {
            transactionService.withdraw(getUserIdFromPrincipal(principal), amount);
            model.addAttribute("successMessage", "Withdrawal successful!");
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/dashboard";
    }

    private Long getUserIdFromPrincipal(Principal principal) {
        return userRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new IllegalArgumentException("User not found"))
                .getId();
    }

    @PostMapping("/transfer")
    public String transfer(@RequestParam Long receiverId,
                           @RequestParam BigDecimal amount,
                           Model model,
                           Principal principal) {
        try {
            System.out.println("Initiating transfer...");
            Long senderId = getUserIdFromPrincipal(principal);
            transactionService.transfer(senderId, receiverId, amount);
            model.addAttribute("successMessage", "Transfer successful!");
            System.out.println("Transfer successful!");
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
            System.err.println("Transfer error: " + e.getMessage());
        }
        return "redirect:/dashboard";
    }

}
