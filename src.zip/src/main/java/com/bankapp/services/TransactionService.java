package com.bankapp.services;

import com.bankapp.models.Transaction;
import com.bankapp.models.User;
import com.bankapp.repositories.UserRepository;
import com.bankapp.repositories.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private UserRepository userRepository;

    public void deposit(Long userId, BigDecimal amount) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        Transaction transaction = new Transaction();
        transaction.setUser(user);
        transaction.setTransactionType("DEPOSIT");
        transaction.setAmount(amount);
        transactionRepository.save(transaction);
    }

    public void withdraw(Long userId, BigDecimal amount) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        BigDecimal totalBalance = getUserBalance(userId);
        if (totalBalance.compareTo(amount) < 0) {
            throw new IllegalArgumentException("Insufficient funds");
        }

        Transaction transaction = new Transaction();
        transaction.setUser(user);
        transaction.setTransactionType("WITHDRAW");
        transaction.setAmount(amount);
        transactionRepository.save(transaction);
    }

    public BigDecimal getUserBalance(Long userId) {
        List<Transaction> transactions = transactionRepository.findByUserId(userId);
        return transactions.stream()
                .map(t -> t.getTransactionType().equals("DEPOSIT") ? t.getAmount() : t.getAmount().negate())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void transfer(Long senderId, Long receiverId, BigDecimal amount) {
        System.out.println("Transfer initiated: Sender ID=" + senderId + ", Receiver ID=" + receiverId + ", Amount=" + amount);

        try {
            // ดึงข้อมูลผู้ส่งและผู้รับ
            User sender = userRepository.findById(senderId)
                    .orElseThrow(() -> new IllegalArgumentException("Sender not found"));
            User receiver = userRepository.findById(receiverId)
                    .orElseThrow(() -> new IllegalArgumentException("Receiver not found"));

            // ตรวจสอบยอดเงินในบัญชีของผู้ส่ง
            BigDecimal senderBalance = getUserBalance(senderId);
            if (senderBalance.compareTo(amount) < 0) {
                throw new IllegalArgumentException("Insufficient funds");
            }

            // สร้างธุรกรรม: หักเงินจากผู้ส่ง
            Transaction senderTransaction = new Transaction();
            senderTransaction.setUser(sender);
            senderTransaction.setTransactionType("TRANSFER_OUT");
            senderTransaction.setAmount(amount.negate()); // ลดเงินผู้ส่ง
            transactionRepository.save(senderTransaction);

            // สร้างธุรกรรม: เพิ่มเงินให้ผู้รับ
            Transaction receiverTransaction = new Transaction();
            receiverTransaction.setUser(receiver);
            receiverTransaction.setTransactionType("TRANSFER_IN");
            receiverTransaction.setAmount(amount); // เพิ่มเงินผู้รับ
            transactionRepository.save(receiverTransaction);

            System.out.println("Transfer completed: Sender ID=" + senderId + ", Receiver ID=" + receiverId + ", Amount=" + amount);
        } catch (Exception e) {
            System.err.println("Transfer failed: " + e.getMessage());
            throw e; // ส่ง Error กลับไป
        }
    }

    public List<Transaction> getTransactionHistory(Long userId) {
        return transactionRepository.findByUserId(userId);
    }

}
